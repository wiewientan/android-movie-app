<?php
require_once('config.php');

$date = isset($_GET['date']) ? $_GET['date'] : null;

if ($date) {
    $sql = "SELECT * FROM movies WHERE date_release = '$date'";
} else {
    $sql = "SELECT * FROM movies";
}

$result = $conn->query($sql);
$movies = array();

while($row = $result->fetch_assoc()) {
    $movies[] = $row;
}

echo json_encode($movies);
?>