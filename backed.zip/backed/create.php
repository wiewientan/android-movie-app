<?php
require_once('config.php');

$name = $_POST['name'];
$category = $_POST['category'];
$date = $_POST['date'];

$sql = "INSERT INTO movies (name, category, date_release) VALUES ('$name', '$category', '$date')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Movie Registered"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>