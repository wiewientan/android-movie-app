<?php
require_once('config.php');

$id = $_POST['id'];
$name = $_POST['name'];
$category = $_POST['category'];
$date = $_POST['date'];

$sql = "UPDATE movies SET name='$name', category='$category', date_release='$date' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Update Success";
} else {
    echo "Error: " . $conn->error;
}
?>